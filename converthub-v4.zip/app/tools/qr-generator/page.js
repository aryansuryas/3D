import { QrGeneratorClient } from './QrGeneratorClient'

export const metadata = {
  title: 'QR Code Generator — ConvertHub',
  description:
    'Turn text, links, or a whole list of URLs into scannable QR codes. Batch export as PNG or SVG, styled your way — free and instant.',
}

export default function Page() {
  return <QrGeneratorClient />
}
