import { PdfToDocClient } from './PdfToDocClient'

export const metadata = {
  title: 'PDF to Document — ConvertHub',
  description:
    'Extract the text from a PDF and rebuild it as an editable .docx file, right in your browser — nothing is uploaded.',
}

export default function Page() {
  return <PdfToDocClient />
}
