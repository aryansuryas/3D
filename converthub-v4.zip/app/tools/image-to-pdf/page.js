import { ImageToPdfClient } from './ImageToPdfClient'

export const metadata = {
  title: 'Image to PDF — ConvertHub',
  description:
    'Combine JPG, PNG, or WebP images into a single ordered PDF right in your browser. Drag to reorder, pick a page size, and download — nothing is uploaded.',
}

export default function Page() {
  return <ImageToPdfClient />
}
