import { DocToPdfClient } from './DocToPdfClient'

export const metadata = {
  title: 'Document to PDF — ConvertHub',
  description:
    'Convert .docx Word documents into clean, paginated PDFs right in your browser — headings, paragraphs, and lists preserved. Nothing is uploaded.',
}

export default function Page() {
  return <DocToPdfClient />
}
